package exceptions;

public class BombOnFieldException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5812720914732782601L;

	public BombOnFieldException() {
		super("Here is a bomb");
	}


}
