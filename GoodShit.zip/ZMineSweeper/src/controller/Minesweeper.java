package controller;

public class Minesweeper {


	public static void main(String[] args) {

		GameLoop gameloop = new GameLoop();
		gameloop.run();

	}

}
